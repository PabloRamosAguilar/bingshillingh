<script>
    export let busqueda = "";
</script>

<input type="search" bind:value={busqueda} />
